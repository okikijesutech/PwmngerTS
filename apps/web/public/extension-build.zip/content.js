const d="abcdefghijklmnopqrstuvwxyz",m="ABCDEFGHIJKLMNOPQRSTUVWXYZ",f="0123456789",w="!@#$%^&*()_+-=[]{}|;:,.<>?";function g(t){let e="";if(e+=d,e+=m,e+=f,e+=w,!e)throw new Error("No character sets selected");const r=[],n=crypto.getRandomValues(new Uint32Array(t.length));for(let o=0;o<t.length;o++)r.push(e[n[o]%e.length]);return r.join("")}console.log("PwmngerTS Content Script Loaded");const y=`
  .pwmnger-icon {
    position: absolute;
    right: 8px;
    top: 50%;
    transform: translateY(-50%);
    width: 20px;
    height: 20px;
    background-image: url('${chrome.runtime.getURL("icon.png")}'); 
    background-size: contain;
    background-repeat: no-repeat;
    cursor: pointer;
    z-index: 10000;
    opacity: 0.5;
    transition: opacity 0.2s;
  }
  .pwmnger-icon:hover {
    opacity: 1;
  }
  .pwmnger-wrapper {
    position: relative;
    display: inline-block;
    width: 100%;
  }
`,c=document.createElement("style");c.innerText=y;document.head.appendChild(c);chrome.runtime.onMessage.addListener((t,e,r)=>{if(t.action==="autofill"){const{username:n,password:o}=t;h(n,o)}});function h(t,e){const r=document.querySelectorAll('input[type="password"]');if(r.length===0){console.log("No password fields found for auto-fill");return}for(const n of Array.from(r)){i(n,e);const o=l(n);o&&i(o,t)}}function l(t){const e=t.form;if(e){const o=['input[type="email"]','input[name*="user"]','input[name*="email"]','input[name*="login"]','input[id*="user"]','input[id*="email"]','input[autocomplete="username"]','input[type="text"]'];for(const s of o){const a=e.querySelector(s);if(a&&a!==t&&a.type!=="hidden"&&a.type!=="submit")return a}}const r=Array.from(document.querySelectorAll("input")),n=r.indexOf(t);if(n>0)for(let o=n-1;o>=0;o--){const s=r[o];if((s.type==="text"||s.type==="email")&&s.style.display!=="none")return s}return null}function i(t,e){t.focus(),t.value=e,t.dispatchEvent(new Event("input",{bubbles:!0})),t.dispatchEvent(new Event("change",{bubbles:!0})),t.blur()}function p(){document.querySelectorAll('input[type="password"]').forEach(e=>{if(e.dataset.pwmngerInjected)return;const r=document.createElement("div");r.className="pwmnger-wrapper";const n=e.parentElement;if(n){window.getComputedStyle(n).position==="static"&&(n.style.position="relative");const s=document.createElement("div");s.className="pwmnger-icon",s.title="Generate Secure Password",s.onclick=a=>{a.preventDefault(),a.stopPropagation();const u=g({length:16});i(e,u)},n.appendChild(s),e.dataset.pwmngerInjected="true"}})}setInterval(p,2e3);p();document.addEventListener("submit",t=>{const e=t.target;if(!e)return;const r=e.querySelector('input[type="password"]');if(!r||!r.value)return;const n=l(r),o=n?n.value:"",s=r.value,a=window.location.hostname;s&&chrome.runtime.sendMessage({action:"capture-credentials",site:a,username:o,password:s})},!0);
