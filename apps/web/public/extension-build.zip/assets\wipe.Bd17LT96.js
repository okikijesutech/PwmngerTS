function e(n){n.fill(0)}function r(n){return new TextEncoder().encode(n)}export{r as s,e as w};
